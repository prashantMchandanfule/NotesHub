#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;
vector<vector<char>> readCSV(const string &filename)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cout << "File not found: " << filename << endl;
        exit(EXIT_FAILURE);
    }
    vector<vector<char>> data;
    string line;
    getline(file, line); 
    while (getline(file, line))
    {
        stringstream ss(line);
        string value;
        vector<char> row;
        getline(ss, value, ','); 

        while (getline(ss, value, ','))
        {
            row.push_back(value[0]);
        }
        data.push_back(row);
    }
    return data;
}
double findCorrelation(const vector<vector<char>> &data, int tid1, int tid2)
{
    int tid1_count = 0, tid2_count = 0, total_common_count = 0;

    for (size_t j = 0; j < data[0].size(); ++j)
    {
        if (data[tid1][j] == 'Y')
            tid1_count++;
        if (data[tid2][j] == 'Y')
            tid2_count++;
        if (data[tid1][j] == 'Y' && data[tid2][j] == 'Y')
            total_common_count++;
    }
    if (tid1_count == 0 || tid2_count == 0)
        return 0.0;
    return static_cast<double>(total_common_count) / (tid1_count * tid2_count);
}
void writeCSV(const string &filename, const vector<vector<string>> &data)
{
    ofstream file(filename);
    file << "item 1 with tid,item 2 with tid,Correlation coefficient,Type of correlation\n";
    for (const auto &row : data)
    {
        for (size_t i = 0; i < row.size(); ++i)
        {
            file << row[i];
            if (i < row.size() - 1)
                file << ",";
        }
        file << "\n";
    }
}
int main()
{
    vector<vector<char>> data = readCSV("Correlation_Input.csv");
    int n = data.size();
    vector<vector<string>> output_data;
    cout << fixed << setprecision(16);
    for (int i = 0; i < n; ++i)
    {
        for (int j = i + 1; j < n; ++j)
        {
        double correlation = findCorrelation(data, i, j);
        string verdict = (correlation > 0) ? "Positive correlation" : "No relationship between entities";
        vector<string> row = {to_string(i + 1), to_string(j + 1), to_string(correlation), verdict};
        output_data.push_back(row);
        }
    }

    writeCSV("Correlation_Output.csv", output_data);
    cout << "Correlation data has been written to Correlation_Output.csv\n";
    return 0;
}
