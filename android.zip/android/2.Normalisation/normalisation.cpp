#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

int main()
{

    double tmp, mini, maxi, new_mini, new_maxi;
    double sum = 0, cnt = 0, square_sum = 0, mean, standard_deviation;

    int opt;

    cout << "\nEnter option: \n1.Min-Max Normalization \n2.Z-Score "
            "Normalization\nOption : ";
    cin >> opt;

    if (opt == 1)
    {
        ifstream in1("input_MinMax.csv");
        ofstream out1("output_MinMax.csv");
        if (!in1)
        {
            cout << "Error opening file, try again.";
            exit(1);
        }

        in1 >> tmp;
        mini = maxi = tmp;

        while (in1 >> tmp)
        {
            if (tmp > maxi)
                maxi = tmp;
            if (tmp < mini)
                mini = tmp;
        }
        in1.close();

        cout << "Enter new min: ";
        cin >> new_mini;
        cout << "Enter new max: ";
        cin >> new_maxi;

        in1.open("input_MinMax.csv");
        if (!in1)
        {
            cout << "Error reopening file, try again.";
            exit(1);
        }

        out1 << "Data,Normalized Data\n";
        while (in1 >> tmp)
        {
            double tmp2 =
                (((tmp - mini) / (maxi - mini)) * (new_maxi - new_mini)) + new_mini;
            out1 << fixed << setprecision(2) << tmp << "," << tmp2 << "\n";
        }
        in1.close();
        out1.close();
    }
    else if (opt == 2)
    {
        ifstream in3("input_ZScore.csv");
        ofstream out2("output_ZScore.csv");
        if (!in3)
        {
            cout << "Error opening file, try again.";
            exit(1);
        }

        while (in3 >> tmp)
        {
            sum += tmp;
            cnt++;
        }

        mean = sum / cnt;

        in3.clear();
        in3.seekg(0, ios::beg);

        while (in3 >> tmp)
        {
            square_sum += (tmp - mean) * (tmp - mean);
        }

        standard_deviation = sqrt(square_sum / cnt);

        in3.clear();
        in3.seekg(0,ios::beg);

        in3.open("input_ZScore.csv");
        if (!in3)
        {
            cout << "Error reopening file, try again.";
            exit(1);
        }

        out2 << "Data,Z-Score Normalized Data\n";
        while (in3 >> tmp)
        {
            double tmp2 = ((tmp - mean) / standard_deviation);
            out2 << fixed << setprecision(2) << tmp << "," << tmp2 << "\n";
        }
        in3.close();
        out2.close();
    }
    else
    {
        cout << "Wrong Option" << endl;
    }

    return 0;
}