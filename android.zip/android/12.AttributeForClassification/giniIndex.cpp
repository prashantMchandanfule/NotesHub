#include <bits/stdc++.h>
using namespace std;

double gini_of_class(double p1, double p2)
{
    int tot = p1 + p2;
    double tmp1 = (double)pow((p1 / tot), 2.0);
    double tmp2 = (double)pow((p2 / tot), 2.0);
    double ans = 1 - tmp1 - tmp2;
    return ans;
}

double gini_attribute(map<string, map<string, int>> attribute, double count)
{
    double gini = 0.0;
    for (auto i : attribute)
    {
        string val = i.first;
        double play_cnt = attribute[val]["Yes"];
        double noPlay_cnt = attribute[val]["No"];
        double tot = play_cnt + noPlay_cnt;
        gini += (double)(tot / (double)count) * (1 - (play_cnt / tot) * (play_cnt / tot) - (noPlay_cnt / tot) * (noPlay_cnt / tot));
    }
    return gini;
}

int main()
{
    ifstream file("giniinput.csv");
    ofstream fw("output_gini.csv", ios::out);

    string line;
    string PlayGame;
    map<string, int> mainClass;
    map<string, map<string, int>> attributes;
    int count = 0;

    if (!file.is_open())
    {
        perror("Error in opening input file : ");
        return -1;
    }

    int i = 0;
    vector<string> attribute_names;
    while (getline(file, line))
    {
        stringstream str(line);
        string value;
        if (i == 0) 
        {
            
            while (getline(str, value, ','))
            {
                attribute_names.push_back(value); 
            }
            i++;
            continue;
        }
        vector<string> values;
        while (getline(str, value, ','))
        {
            values.push_back(value);
        }

        PlayGame = values.back();
        mainClass[PlayGame]++;

        for (size_t j = 0; j < values.size() - 1; j++) 
        {
            string attribute_name = attribute_names[j];
            attributes[attribute_name][PlayGame]++;
        }
        count++;
    }

    int p1 = mainClass["Yes"];
    int p2 = mainClass["No"];
    double gini_parent = gini_of_class(p1, p2);
    cout << "Gini Index (Main Class): " << gini_parent << endl;
    fw << "Gini Index (Main Class)," << gini_parent << "\n";

    for (const auto &attribute_name : attribute_names)
    {
        if (attribute_name == "PlayGame") 
            continue;
        double gini = gini_attribute(attributes, count);
        cout << "Gini Index (" << attribute_name << "): " << gini << endl;
        fw << "Gini Index (" << attribute_name << ")," << gini << "\n";
    }

    file.close();
    fw.close();
    return 0;
}
