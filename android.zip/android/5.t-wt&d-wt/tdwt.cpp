#include <bits/stdc++.h>
#include <fstream>
#include <iomanip> 
using namespace std;
int main()
{
    fstream file("input.csv", ios::in);
    if (!file.is_open())
    {
        cout << "Couldn't Open file";
        return 0;
    }
    string line, word;
    string col, row, count;
    int val;
    map<string, map<string, int>> classrowcolMap;
    map<string, int> colMap;
    map<string, int> rowMap;
    int i = 0;
    while (getline(file, line))
    {
        stringstream str(line);
        if (i == 0)
        { i++;continue;}
        getline(str, row, ',');
        getline(str, col, ',');
        getline(str, count, ',');
        val = stoi(count);
        classrowcolMap[row][col] = val;
        colMap[col] += val;
        rowMap[row] += val;
    }
    for (auto r : rowMap)
    {
        for (auto c : colMap)
        {
            cout << r.first << "-" << c.first << ": ";
            cout << classrowcolMap[r.first][c.first] << endl;
        }
    }
    for (auto r : rowMap)
    {cout << r.first << " -> " << r.second << endl;}
    for (auto c : colMap)
    { cout << c.first << " -> " << c.second << endl;}
    int colSum = 0, rowSum = 0;
    for (auto c : colMap)
    {
        colSum += c.second;
    }
    cout << "colSum: " << colSum << "\n";
    for (auto r : rowMap)
    {
        rowSum += r.second;
    }
    cout << "rowSum: " << rowSum << "\n";
    ofstream fw("output.csv", ios::out);
    fw << "Column\\Row, Bollywood, , , Tollywood, , , Total\n";
    fw << ",Count, t-weight, d-weight, Count, t-weight, d-weight, Count, t-weight, d-weight\n";
    for (auto r : rowMap)
    {
        row = r.first;
        fw << row << ",";
        for (auto c : colMap)
        {  col = c.first;
            int value = classrowcolMap[row][col];
            fw << value << ",";
            fw << fixed << setprecision(2)
               << ((float)value / rowMap[row]) * 100 << "%,"; 
            fw << fixed << setprecision(2)
               << ((float)value / colMap[col]) * 100 << "%,"; 
        }
        fw << rowMap[row] << ",";
        fw << "100%,";                                                                  
        fw << fixed << setprecision(2) << ((float)rowMap[row] / colSum) * 100 << "%\n"; 
    }
    fw << "Total,";
    for (auto c : colMap)
    {
        col = c.first;
        fw << colMap[col] << ",";
        fw << fixed << setprecision(2) << ((float)colMap[col] / colSum) * 100 << "%,"; 
        fw << "100%,";                                                                 
    }
    fw << colSum << ",100%,100%\n";
    fw.close(); 
    return 0;
}
